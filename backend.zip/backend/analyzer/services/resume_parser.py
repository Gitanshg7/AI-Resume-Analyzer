"""
Resume Parser Module
====================
Handles PDF and DOCX file parsing, text cleaning, and NLP preprocessing.

Pipeline:
    1. parse_file()       → raw text from PDF or DOCX
    2. clean_text()       → lowercase, punctuation-free, whitespace-normalized
    3. preprocess_nlp()   → tokenize → stopwords → lemmatize → normalize
    4. extract_email()    → regex email detection
    5. extract_phone()    → regex phone detection
"""

import re
import io
import fitz  # PyMuPDF
from docx import Document as DocxDocument

# Lazy-loaded spaCy model (loaded once on first call)
_nlp = None


def _get_nlp():
    """Load spaCy model lazily to avoid import-time overhead."""
    global _nlp
    if _nlp is None:
        import spacy
        _nlp = spacy.load("en_core_web_sm")
    return _nlp


# ── File Parsing ─────────────────────────────────────────────────────────


def parse_pdf(file_obj) -> str:
    """
    Extract text from a PDF file using PyMuPDF.
    Falls back to OCR (pytesseract) for image-based/scanned PDFs.

    Args:
        file_obj: A file-like object or Django UploadedFile.

    Returns:
        Extracted text as a single string.
    """
    file_bytes = file_obj.read()
    doc = fitz.open(stream=file_bytes, filetype="pdf")
    text_parts = []
    for page in doc:
        text_parts.append(page.get_text())

    text = "\n".join(text_parts)

    # If no text extracted, try OCR (scanned/image-based PDF)
    if not text.strip():
        text = _ocr_pdf(doc)

    doc.close()
    return text


def _ocr_pdf(doc) -> str:
    """
    OCR fallback: render each PDF page to an image and run Tesseract.

    Args:
        doc: An open fitz.Document.

    Returns:
        OCR-extracted text as a single string.
    """
    try:
        import pytesseract
        from PIL import Image

        # Set Tesseract path for Windows
        import shutil
        if not shutil.which("tesseract"):
            tesseract_path = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
            import os
            if os.path.exists(tesseract_path):
                pytesseract.pytesseract.tesseract_cmd = tesseract_path

        text_parts = []
        for page in doc:
            # Render page at 300 DPI for good OCR accuracy
            mat = fitz.Matrix(300 / 72, 300 / 72)
            pix = page.get_pixmap(matrix=mat)
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            page_text = pytesseract.image_to_string(img)
            text_parts.append(page_text)

        return "\n".join(text_parts)
    except ImportError:
        return ""
    except Exception as exc:
        import logging
        logging.getLogger(__name__).warning(f"OCR fallback failed: {exc}")
        return ""


def parse_docx(file_obj) -> str:
    """
    Extract text from a DOCX file using python-docx.

    Args:
        file_obj: A file-like object or Django UploadedFile.

    Returns:
        Extracted text as a single string.
    """
    file_bytes = file_obj.read()
    doc = DocxDocument(io.BytesIO(file_bytes))
    text_parts = []
    for para in doc.paragraphs:
        if para.text.strip():
            text_parts.append(para.text)
    return "\n".join(text_parts)


def parse_file(file_obj) -> str:
    """
    Route file to the correct parser based on extension.

    Args:
        file_obj: Django UploadedFile with a .name attribute.

    Returns:
        Extracted text string.

    Raises:
        ValueError: If the file type is unsupported.
    """
    name = file_obj.name.lower()
    # Reset file pointer in case it was read before
    if hasattr(file_obj, "seek"):
        file_obj.seek(0)

    if name.endswith(".pdf"):
        return parse_pdf(file_obj)
    elif name.endswith(".docx"):
        return parse_docx(file_obj)
    else:
        raise ValueError(f"Unsupported file type: {name}")


# ── Text Cleaning ───────────────────────────────────────────────────────


def clean_text(text: str) -> str:
    """
    Basic text cleaning pipeline.

    Steps:
        1. Convert to lowercase
        2. Remove non-ASCII characters
        3. Collapse multiple whitespace into single spaces
        4. Strip leading/trailing whitespace

    Args:
        text: Raw extracted text.

    Returns:
        Cleaned text string.
    """
    text = text.lower()
    text = re.sub(r"[^\x00-\x7F]+", " ", text)  # remove non-ASCII
    text = re.sub(r"\s+", " ", text)  # collapse whitespace
    return text.strip()


# ── NLP Preprocessing ───────────────────────────────────────────────────


def preprocess_nlp(text: str) -> str:
    """
    Full NLP preprocessing pipeline using spaCy.

    Steps:
        1. Tokenization
        2. Stopword removal
        3. Lemmatization
        4. Whitespace normalization

    Args:
        text: Cleaned text (output of clean_text).

    Returns:
        Preprocessed text with lemmatized tokens.
    """
    nlp = _get_nlp()
    doc = nlp(text)

    tokens = []
    for token in doc:
        # Skip stopwords, punctuation, and whitespace tokens
        if token.is_stop or token.is_punct or token.is_space:
            continue
        lemma = token.lemma_.strip()
        if lemma:
            tokens.append(lemma)

    return " ".join(tokens)


# ── Contact Extraction ──────────────────────────────────────────────────

EMAIL_PATTERN = re.compile(
    r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
)

PHONE_PATTERN = re.compile(
    r"(?:\+?\d{1,3}[\s\-]?)?"  # optional country code
    r"(?:\(?\d{2,4}\)?[\s\-]?)?"  # optional area code
    r"\d{3,4}[\s\-]?\d{3,4}"  # main number
)


def extract_email(text: str) -> str:
    """Extract the first email address found in text."""
    match = EMAIL_PATTERN.search(text)
    return match.group() if match else ""


def extract_phone(text: str) -> str:
    """Extract the first phone number found in text."""
    match = PHONE_PATTERN.search(text)
    return match.group().strip() if match else ""
