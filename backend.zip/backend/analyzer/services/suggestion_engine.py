"""
Suggestion Engine Module
========================
Generates dynamic, actionable improvement suggestions based on
the resume analysis results.

Suggestions are rule-based, examining:
    - Missing skills
    - Low sub-scores
    - Missing resume sections
    - Experience gaps
    - Keyword density
"""

from typing import List, Dict


# ── Suggestion Rules ─────────────────────────────────────────────────────

IMPORTANT_SKILLS = [
    "Python", "Java", "Javascript", "React", "Node.Js",
    "Sql", "Git", "Docker", "Aws", "Machine Learning",
]

SECTION_SUGGESTIONS = {
    "education": "Add an Education section with your degree, university, and graduation year.",
    "experience": "Add a Work Experience section detailing your professional roles and achievements.",
    "projects": "Include a Projects section showcasing relevant technical or personal projects.",
    "skills": "Add a dedicated Skills section listing your technical and soft skills.",
    "certifications": "Consider adding a Certifications section to highlight industry credentials.",
}


def generate_suggestions(
    skills: List[str],
    education: str,
    experience_years: float,
    score_breakdown: Dict[str, float],
    sections_found: List[str],
) -> List[str]:
    """
    Generate dynamic resume improvement suggestions.

    Args:
        skills: List of detected skills.
        education: Education summary string.
        experience_years: Estimated years of experience.
        score_breakdown: Dict of sub-scores from ATS scoring.
        sections_found: List of detected section names.

    Returns:
        List of actionable suggestion strings.
    """
    suggestions = []

    # ── Missing sections ─────────────────────────────────────────────
    all_expected = {"education", "experience", "projects", "skills", "certifications"}
    missing_sections = all_expected - set(sections_found)

    for section in sorted(missing_sections):
        if section in SECTION_SUGGESTIONS:
            suggestions.append(SECTION_SUGGESTIONS[section])

    # ── Skills suggestions ───────────────────────────────────────────
    skills_lower = {s.lower() for s in skills}
    missing_important = [
        s for s in IMPORTANT_SKILLS
        if s.lower() not in skills_lower
    ]

    if len(skills) < 5:
        suggestions.append(
            "Your resume lists very few skills. Add more relevant technical "
            "skills to improve your ATS score."
        )

    if missing_important:
        top_missing = missing_important[:5]
        suggestions.append(
            f"Consider adding these in-demand skills if applicable: "
            f"{', '.join(top_missing)}."
        )

    # ── Education suggestions ────────────────────────────────────────
    if not education:
        suggestions.append(
            "No education details detected. Include your highest degree, "
            "major, and university name."
        )

    # ── Experience suggestions ───────────────────────────────────────
    if experience_years == 0:
        suggestions.append(
            "No work experience detected. Add your work history with dates, "
            "job titles, and measurable achievements."
        )
    elif experience_years < 2:
        suggestions.append(
            "Limited experience detected. Highlight internships, freelance "
            "work, or academic projects to strengthen this section."
        )

    # ── Score-based suggestions ──────────────────────────────────────
    if score_breakdown.get("keywords", 0) < 10:
        suggestions.append(
            "Your resume has low keyword density. Use more industry-standard "
            "terms and buzzwords relevant to your target role."
        )

    if score_breakdown.get("jd_match", 0) < 10 and score_breakdown.get("jd_match") is not None:
        suggestions.append(
            "Your resume has low alignment with the job description. Tailor "
            "your resume content to match the job requirements."
        )

    if score_breakdown.get("sections", 0) < 8:
        suggestions.append(
            "Your resume is missing key sections. A complete resume typically "
            "includes: Education, Experience, Skills, Projects, and Certifications."
        )

    # ── General best practices ───────────────────────────────────────
    general_tips = []

    if "github" not in " ".join(skills).lower():
        general_tips.append(
            "Include links to your GitHub profile or portfolio website."
        )

    general_tips.append(
        "Use measurable achievements (e.g., 'Reduced API latency by 40%') "
        "instead of generic descriptions."
    )

    general_tips.append(
        "Keep your resume to 1-2 pages and use a clean, ATS-friendly format "
        "without complex tables or graphics."
    )

    suggestions.extend(general_tips)

    return suggestions
