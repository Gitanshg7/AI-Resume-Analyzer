"""
ATS Scoring Module
==================
Implements a weighted ATS (Applicant Tracking System) scoring algorithm.

Scoring Features & Weights:
    Skill Match           25%
    Experience Relevance  20%
    Education             10%
    Keyword Density       15%
    Job Description Match 20%  (redistributed if no JD provided)
    Section Completeness  10%

Returns:
    {
        "score": float (0-100),
        "breakdown": { category: sub_score },
        "sections_found": [str],
        "keyword_matches": [str],
        "missing_keywords": [str],
    }
"""

import re
from typing import Dict, List, Any

# ── Weights (sum = 1.0) ─────────────────────────────────────────────────

WEIGHTS = {
    "skills": 0.25,
    "experience": 0.20,
    "education": 0.10,
    "keywords": 0.15,
    "jd_match": 0.20,
    "sections": 0.10,
}

# When no job description is provided, redistribute JD weight
WEIGHTS_NO_JD = {
    "skills": 0.32,
    "experience": 0.25,
    "education": 0.13,
    "keywords": 0.20,
    "jd_match": 0.00,
    "sections": 0.10,
}

# ── Expected ATS Keywords ───────────────────────────────────────────────

EXPECTED_KEYWORDS = [
    "python", "java", "javascript", "react", "node.js", "sql", "mongodb",
    "aws", "docker", "kubernetes", "machine learning", "deep learning",
    "data analysis", "rest api", "git", "agile", "ci/cd",
    "communication", "leadership", "teamwork", "problem solving",
    "project management", "research", "testing",
]

# ── Resume Sections ─────────────────────────────────────────────────────

EXPECTED_SECTIONS = {
    "education": [
        r"\beducation\b", r"\bacademic\b", r"\bqualification\b",
    ],
    "experience": [
        r"\bexperience\b", r"\bwork\s*history\b", r"\bemployment\b",
        r"\bprofessional\s*experience\b",
    ],
    "projects": [
        r"\bprojects?\b", r"\bportfolio\b",
    ],
    "skills": [
        r"\bskills?\b", r"\btechnical\s*skills?\b", r"\bcompetenc\b",
    ],
    "certifications": [
        r"\bcertificat\b", r"\blicenses?\b", r"\baccreditation\b",
    ],
}


# ── Scoring Functions ────────────────────────────────────────────────────


def _score_skills(skills: List[str], max_score: float = 100.0) -> float:
    """
    Score based on number of detected skills.
    0 skills → 0, 5 skills → 50, 10+ skills → 100.
    """
    count = len(skills)
    if count == 0:
        return 0.0
    if count >= 10:
        return max_score
    return min((count / 10) * max_score, max_score)


def _score_experience(years: float, max_score: float = 100.0) -> float:
    """
    Score based on estimated experience.
    0 years → 20 (entry-level baseline), 5+ years → 100.
    """
    if years <= 0:
        return 20.0  # entry-level still gets some credit
    if years >= 5:
        return max_score
    return min(20.0 + (years / 5) * 80.0, max_score)


def _score_education(education: str, max_score: float = 100.0) -> float:
    """
    Score based on detected education level.
    """
    if not education:
        return 0.0

    edu_lower = education.lower()
    if any(d in edu_lower for d in ["phd", "doctorate"]):
        return max_score
    if any(d in edu_lower for d in ["m.tech", "m.sc", "m.s", "m.e", "mba", "masters", "master"]):
        return max_score * 0.9
    if any(d in edu_lower for d in ["b.tech", "b.e", "b.sc", "b.s", "b.a", "bca", "bachelors", "bachelor"]):
        return max_score * 0.75
    if "diploma" in edu_lower:
        return max_score * 0.5

    return max_score * 0.3  # some education detected


def _score_keywords(text: str) -> tuple:
    """
    Score keyword density against expected ATS keywords.
    Returns (score, matched_keywords, missing_keywords).
    """
    text_lower = text.lower()
    matched = []
    missing = []

    for kw in EXPECTED_KEYWORDS:
        if kw in text_lower:
            matched.append(kw)
        else:
            missing.append(kw)

    total = len(EXPECTED_KEYWORDS)
    ratio = len(matched) / total if total > 0 else 0
    score = min(ratio * 100, 100.0)

    return score, matched, missing


def _detect_sections(text: str) -> List[str]:
    """
    Detect which resume sections are present.
    Returns list of section names found.
    """
    found = []
    for section_name, patterns in EXPECTED_SECTIONS.items():
        for pattern in patterns:
            if re.search(pattern, text, re.IGNORECASE):
                found.append(section_name)
                break
    return found


def _score_sections(sections_found: List[str], max_score: float = 100.0) -> float:
    """
    Score based on section completeness.
    Each expected section contributes equally.
    """
    total_expected = len(EXPECTED_SECTIONS)
    found_count = len(sections_found)
    return (found_count / total_expected) * max_score if total_expected > 0 else 0.0


def _score_jd_match(text: str, job_description: str) -> float:
    """
    Score resume-to-job-description match using TF-IDF cosine similarity
    and keyword overlap.

    Returns a score 0–100.
    """
    if not job_description or not job_description.strip():
        return 0.0

    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.metrics.pairwise import cosine_similarity

        vectorizer = TfidfVectorizer(stop_words="english", max_features=5000)
        tfidf_matrix = vectorizer.fit_transform([text, job_description])
        cos_sim = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]

        # Keyword overlap
        resume_words = set(text.lower().split())
        jd_words = set(job_description.lower().split())
        if jd_words:
            overlap_ratio = len(resume_words & jd_words) / len(jd_words)
        else:
            overlap_ratio = 0.0

        # Blend: 60% cosine similarity + 40% keyword overlap
        blended = (cos_sim * 0.6 + overlap_ratio * 0.4) * 100
        return min(blended, 100.0)

    except Exception:
        return 0.0


# ── Main Entry Point ────────────────────────────────────────────────────


def calculate_ats_score(
    text: str,
    skills: List[str],
    education: str,
    experience_years: float,
    job_description: str = "",
) -> Dict[str, Any]:
    """
    Calculate the overall ATS resume score with per-category breakdown.

    Args:
        text: Cleaned resume text.
        skills: List of extracted skills.
        education: Education summary string.
        experience_years: Estimated years of experience.
        job_description: Optional job description text for JD matching.

    Returns:
        Dict with keys: score, breakdown, sections_found,
                        keyword_matches, missing_keywords
    """
    has_jd = bool(job_description and job_description.strip())
    weights = WEIGHTS if has_jd else WEIGHTS_NO_JD

    # Calculate raw sub-scores (each 0–100)
    skills_score = _score_skills(skills)
    experience_score = _score_experience(experience_years)
    education_score = _score_education(education)
    keyword_score, keyword_matches, missing_keywords = _score_keywords(text)
    sections_found = _detect_sections(text)
    sections_score = _score_sections(sections_found)
    jd_score = _score_jd_match(text, job_description) if has_jd else 0.0

    # Weighted final score
    breakdown = {
        "skills": round(skills_score * weights["skills"], 1),
        "experience": round(experience_score * weights["experience"], 1),
        "education": round(education_score * weights["education"], 1),
        "keywords": round(keyword_score * weights["keywords"], 1),
        "jd_match": round(jd_score * weights["jd_match"], 1),
        "sections": round(sections_score * weights["sections"], 1),
    }

    final_score = round(sum(breakdown.values()), 1)
    final_score = min(final_score, 100.0)

    return {
        "score": final_score,
        "breakdown": breakdown,
        "sections_found": sections_found,
        "keyword_matches": keyword_matches,
        "missing_keywords": missing_keywords,
    }
