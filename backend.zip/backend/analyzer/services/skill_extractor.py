"""
Skill Extractor Module
======================
Three-layer skill extraction from resume text:

1. **spaCy PhraseMatcher**  – catches multi-word skills accurately
2. **Dictionary matching**  – case-insensitive lookups against a curated list
3. **spaCy NER**            – ORG/PRODUCT entities as supplemental signals

Returns a deduplicated, title-cased list of skills.
"""

from typing import List

# Lazy-loaded spaCy objects
_nlp = None
_phrase_matcher = None


# ── Curated Skills Dictionary ────────────────────────────────────────────

SKILLS_DATABASE = [
    # Programming Languages
    "python", "java", "javascript", "typescript", "c++", "c#", "c",
    "go", "rust", "ruby", "php", "swift", "kotlin", "scala", "r",
    "matlab", "perl", "shell", "bash",
    # Web Technologies
    "react", "angular", "vue.js", "vue", "next.js", "node.js", "express",
    "django", "flask", "fastapi", "spring boot", "spring",
    "html", "css", "tailwind", "bootstrap", "sass",
    # Data & AI
    "machine learning", "deep learning", "natural language processing",
    "computer vision", "data analysis", "data science", "data engineering",
    "artificial intelligence", "neural networks", "reinforcement learning",
    "tensorflow", "pytorch", "keras", "scikit-learn", "pandas", "numpy",
    "matplotlib", "opencv", "nltk", "spacy", "hugging face",
    # Databases
    "sql", "mysql", "postgresql", "mongodb", "redis", "elasticsearch",
    "cassandra", "dynamodb", "firebase", "sqlite", "oracle",
    # Cloud & DevOps
    "aws", "azure", "gcp", "google cloud", "cloud computing",
    "docker", "kubernetes", "terraform", "ansible", "jenkins",
    "ci/cd", "github actions", "gitlab ci",
    # Tools & Platforms
    "linux", "git", "jira", "confluence", "figma",
    "rest api", "graphql", "grpc", "microservices",
    "agile", "scrum",
    # Other
    "power bi", "tableau", "excel", "hadoop", "spark", "kafka",
    "blockchain", "cybersecurity", "penetration testing",
]

# Normalized set for fast lookups
_SKILLS_SET = {s.lower() for s in SKILLS_DATABASE}


def _get_nlp_and_matcher():
    """Initialize spaCy NLP and PhraseMatcher lazily."""
    global _nlp, _phrase_matcher
    if _nlp is None:
        import spacy
        from spacy.matcher import PhraseMatcher

        _nlp = spacy.load("en_core_web_sm")

        # Build PhraseMatcher with all skills as patterns
        _phrase_matcher = PhraseMatcher(_nlp.vocab, attr="LOWER")
        patterns = [_nlp.make_doc(skill) for skill in SKILLS_DATABASE]
        _phrase_matcher.add("SKILLS", patterns)

    return _nlp, _phrase_matcher


def _extract_via_phrase_matcher(text: str) -> List[str]:
    """Layer 1: Use spaCy PhraseMatcher for accurate multi-word skill detection."""
    nlp, matcher = _get_nlp_and_matcher()
    doc = nlp(text)
    matches = matcher(doc)

    found = set()
    for match_id, start, end in matches:
        span_text = doc[start:end].text.lower()
        found.add(span_text)

    return list(found)


def _extract_via_dictionary(text: str) -> List[str]:
    """Layer 2: Case-insensitive dictionary matching using the curated skills list."""
    text_lower = text.lower()
    found = set()

    for skill in SKILLS_DATABASE:
        if skill in text_lower:
            found.add(skill)

    return list(found)


def _extract_via_ner(text: str) -> List[str]:
    """Layer 3: Use spaCy NER to detect ORG/PRODUCT entities as potential skills."""
    nlp, _ = _get_nlp_and_matcher()
    doc = nlp(text)

    found = set()
    for ent in doc.ents:
        if ent.label_ in ("ORG", "PRODUCT"):
            ent_lower = ent.text.lower().strip()
            # Only include if it matches a known skill
            if ent_lower in _SKILLS_SET:
                found.add(ent_lower)

    return list(found)


def extract_skills(text: str) -> List[str]:
    """
    Extract skills from resume text using a three-layer approach.

    Args:
        text: Cleaned resume text (lowercase).

    Returns:
        Deduplicated, title-cased list of detected skills.
    """
    all_skills = set()

    # Layer 1: PhraseMatcher (most accurate for multi-word)
    all_skills.update(_extract_via_phrase_matcher(text))

    # Layer 2: Dictionary matching (catches single-word + edge cases)
    all_skills.update(_extract_via_dictionary(text))

    # Layer 3: NER supplemental (only known skills)
    all_skills.update(_extract_via_ner(text))

    # Title-case for display
    return sorted([skill.title() for skill in all_skills])
