"""
MongoEngine document models for resume storage and analysis results.
Uses MongoEngine ODM (not Django ORM) for MongoDB Atlas.
"""

import datetime
from mongoengine import (
    Document,
    StringField,
    ListField,
    FloatField,
    DictField,
    DateTimeField,
    ReferenceField,
    CASCADE,
)


class Resume(Document):
    """
    Stores uploaded resume data and extracted information.

    Fields:
        file_name       – original uploaded file name
        parsed_text     – full extracted text from the resume
        email           – detected email address
        phone           – detected phone number
        skills          – list of extracted skill strings
        education       – detected education summary string
        experience_years – estimated years of experience
        score           – overall ATS score (0–100)
        uploaded_at     – timestamp of upload
    """

    file_name = StringField(required=True, max_length=255)
    parsed_text = StringField(default="")
    email = StringField(default="")
    phone = StringField(default="")
    skills = ListField(StringField(), default=list)
    education = StringField(default="")
    experience_years = FloatField(default=0.0)
    score = FloatField(default=0.0)
    uploaded_at = DateTimeField(default=datetime.datetime.utcnow)

    meta = {
        "collection": "resumes",
        "ordering": ["-uploaded_at"],
    }

    def __str__(self):
        return f"Resume({self.file_name}, score={self.score})"


class ResumeAnalysis(Document):
    """
    Stores detailed ATS analysis results linked to a Resume.

    Fields:
        resume          – reference to the parent Resume document
        suggestions     – list of improvement suggestion strings
        keyword_matches – list of keywords found in the resume
        missing_keywords – list of expected keywords not found
        score_breakdown – dict with sub-scores per category
        sections_found  – list of detected resume sections
        job_description – optional JD text used for matching
        analyzed_at     – timestamp of analysis
    """

    resume = ReferenceField(Resume, required=True, reverse_delete_rule=CASCADE)
    suggestions = ListField(StringField(), default=list)
    keyword_matches = ListField(StringField(), default=list)
    missing_keywords = ListField(StringField(), default=list)
    score_breakdown = DictField(default=dict)
    sections_found = ListField(StringField(), default=list)
    job_description = StringField(default="")
    analyzed_at = DateTimeField(default=datetime.datetime.utcnow)

    meta = {
        "collection": "resume_analyses",
        "ordering": ["-analyzed_at"],
    }

    def __str__(self):
        return f"Analysis(resume={self.resume.file_name})"
